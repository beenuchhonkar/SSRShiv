import React from "react";
function Home(props) {
    return <h1>Hello {props.name} !</h1>;
  };
  
  export default Home;